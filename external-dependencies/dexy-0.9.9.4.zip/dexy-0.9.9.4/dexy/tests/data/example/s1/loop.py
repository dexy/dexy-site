for i in xrange(5):
    print i

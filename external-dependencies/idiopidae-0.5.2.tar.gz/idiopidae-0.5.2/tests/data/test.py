from collections import *

### @export "Beginning Preamble" python

class MyClass:
    def __init__(self):
        pass

    ### @export "Main Function" python
    def main(self, args):
        pass

### @export "Closing" python

if __name__=='__main__':
    print "my name is main"
    a = MyClass()

### @end

# this should not show up


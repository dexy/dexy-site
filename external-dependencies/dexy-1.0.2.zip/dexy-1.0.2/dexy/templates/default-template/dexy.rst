this is meta for default template

### @export "assign-variables"
x = 5
y = 7

### @export "multiply"
x * y


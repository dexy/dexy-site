from dexy.dexy_filter import DexyFilter

def test_filter():
    DexyFilter()

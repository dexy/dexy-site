"""
   Zapps -- Zeds Additional Python Parsing System
   It's just a simple fork based on Amit's work in yapps2.
"""

__version__ = "0.5"
__copyright__ = "Copyright (C) Amit, Zapps modifications by Zed."

import rt
import parser
import support

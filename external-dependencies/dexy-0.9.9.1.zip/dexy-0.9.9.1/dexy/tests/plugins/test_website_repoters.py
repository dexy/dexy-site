def test_nav_directories():
    pass
